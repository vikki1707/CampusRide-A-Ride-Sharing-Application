import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FindRideScreen extends StatelessWidget {
  const FindRideScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final currentUserId = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(title: const Text("Find Ride"), centerTitle: true),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('rides')
            .where('postedBy', isNotEqualTo: currentUserId)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());

          final rides = snapshot.data!.docs;

          if (rides.isEmpty) return const Center(child: Text("No rides available."));

          return ListView.builder(
            itemCount: rides.length,
            itemBuilder: (context, index) {
              final ride = rides[index];
              final data = ride.data() as Map<String, dynamic>;
              final requestedBy = List<String>.from(data['requestedBy'] ?? []);
              final approvedBy = List<String>.from(data['approvedBy'] ?? []);

              final alreadyRequested = requestedBy.contains(currentUserId);
              final isApproved = approvedBy.contains(currentUserId);

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                elevation: 4,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  title: Text("${data['from']} → ${data['to']}"),
                  subtitle: Text(
                      "Seats: ${data['seatsAvailable']}  |  Date: ${DateTime.fromMillisecondsSinceEpoch(data['dateTime'].millisecondsSinceEpoch)}"),
                  trailing: alreadyRequested
                      ? Text(isApproved ? "Approved" : "Requested")
                      : ElevatedButton(
                    onPressed: () async {
                      await FirebaseFirestore.instance
                          .collection('rides')
                          .doc(ride.id)
                          .update({
                        'requestedBy': FieldValue.arrayUnion([currentUserId])
                      });
                    },
                    child: const Text("Request"),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
