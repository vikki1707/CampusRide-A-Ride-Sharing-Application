import 'package:flutter/material.dart';
import 'user_data.dart';

class MyRidesScreen extends StatefulWidget {
  const MyRidesScreen({super.key});

  @override
  State<MyRidesScreen> createState() => _MyRidesScreenState();
}

class _MyRidesScreenState extends State<MyRidesScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Rides"),
        backgroundColor: Colors.amber.shade700,
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: "Rides Traveled"),
            Tab(text: "Ride Requests"),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // ✅ Section 1: Rides Traveled
          UserData.rides.isEmpty
              ? const Center(child: Text("No rides offered yet."))
              : ListView.builder(
            itemCount: UserData.rides.length,
            itemBuilder: (context, index) {
              final ride = UserData.rides[index];
              return Card(
                margin: const EdgeInsets.symmetric(
                    horizontal: 15, vertical: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 3,
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.amber.shade700,
                    child: const Icon(Icons.directions_bike,
                        color: Colors.black),
                  ),
                  title: Row(
                    children: [
                      Text(
                        "${ride["from"]} → ${ride["to"]}",
                        style:
                        const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      if (ride["isVerified"] == true) ...[
                        const SizedBox(width: 6),
                        const Icon(Icons.verified,
                            color: Colors.blue, size: 18),
                      ]
                    ],
                  ),
                  subtitle: Text("Seats: ${ride["seats"]}"),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () {
                      setState(() {
                        UserData.rides.removeAt(index);
                      });
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Ride removed")),
                      );
                    },
                  ),
                ),
              );
            },
          ),

          // ✅ Section 2: Ride Requests
          UserData.rideRequests.isEmpty
              ? const Center(child: Text("No ride requests received."))
              : ListView.builder(
            itemCount: UserData.rideRequests.length,
            itemBuilder: (context, index) {
              final request = UserData.rideRequests[index];
              return Card(
                margin: const EdgeInsets.symmetric(
                    horizontal: 15, vertical: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 3,
                child: ListTile(
                  leading: const Icon(Icons.person, color: Colors.black),
                  title: Text("Request from ${request["name"]}"),
                  subtitle: Text(
                      "For ride: ${request["from"]} → ${request["to"]}\nStatus: ${request["status"]}"),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.check_circle,
                            color: Colors.green),
                        onPressed: () {
                          setState(() {
                            request["status"] = "Approved";
                          });
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                                content: Text(
                                    "Ride approved for ${request["name"]}")),
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.cancel, color: Colors.red),
                        onPressed: () {
                          setState(() {
                            request["status"] = "Rejected";
                          });
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                                content: Text(
                                    "Ride rejected for ${request["name"]}")),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
