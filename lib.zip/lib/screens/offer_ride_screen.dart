import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class OfferRideScreen extends StatefulWidget {
  const OfferRideScreen({super.key});

  @override
  State<OfferRideScreen> createState() => _OfferRideScreenState();
}

class _OfferRideScreenState extends State<OfferRideScreen> {
  final _formKey = GlobalKey<FormState>();
  final fromController = TextEditingController();
  final toController = TextEditingController();
  final seatsController = TextEditingController();
  DateTime selectedDateTime = DateTime.now();

  @override
  Widget build(BuildContext context) {
    final currentUserId = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(title: const Text("Offer a Ride"), centerTitle: true),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // ===== Ride Posting Form =====
            Form(
              key: _formKey,
              child: Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      TextFormField(
                        controller: fromController,
                        decoration: const InputDecoration(labelText: "From"),
                        validator: (value) =>
                        value!.isEmpty ? "Enter source" : null,
                      ),
                      TextFormField(
                        controller: toController,
                        decoration: const InputDecoration(labelText: "To"),
                        validator: (value) =>
                        value!.isEmpty ? "Enter destination" : null,
                      ),
                      TextFormField(
                        controller: seatsController,
                        decoration:
                        const InputDecoration(labelText: "Seats Available"),
                        keyboardType: TextInputType.number,
                        validator: (value) =>
                        value!.isEmpty ? "Enter number of seats" : null,
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                              child: Text(
                                  "Date & Time: ${selectedDateTime.toLocal()}".split(".")[0])),
                          TextButton(
                              onPressed: () async {
                                final date = await showDatePicker(
                                  context: context,
                                  initialDate: selectedDateTime,
                                  firstDate: DateTime.now(),
                                  lastDate: DateTime(2100),
                                );
                                if (date != null) {
                                  final time = await showTimePicker(
                                      context: context,
                                      initialTime: TimeOfDay.fromDateTime(
                                          selectedDateTime));
                                  if (time != null) {
                                    setState(() {
                                      selectedDateTime = DateTime(date.year,
                                          date.month, date.day, time.hour, time.minute);
                                    });
                                  }
                                }
                              },
                              child: const Text("Select"))
                        ],
                      ),
                      const SizedBox(height: 12),
                      ElevatedButton(
                        onPressed: () async {
                          if (_formKey.currentState!.validate()) {
                            await FirebaseFirestore.instance
                                .collection('rides')
                                .add({
                              'postedBy': currentUserId,
                              'from': fromController.text,
                              'to': toController.text,
                              'dateTime':
                              Timestamp.fromDate(selectedDateTime),
                              'seatsAvailable':
                              int.parse(seatsController.text),
                              'requestedBy': [],
                            });

                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text("Ride posted!")),
                            );

                            fromController.clear();
                            toController.clear();
                            seatsController.clear();
                            setState(() {
                              selectedDateTime = DateTime.now();
                            });
                          }
                        },
                        child: const Text("Post Ride"),
                      )
                    ],
                  ),
                ),
              ),
            ),

            const SizedBox(height: 24),

            // ===== My Posted Rides with Requests =====
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('rides')
                  .where('postedBy', isEqualTo: currentUserId)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final rides = snapshot.data!.docs;

                if (rides.isEmpty) {
                  return const Text("You haven't posted any rides yet.");
                }

                return ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: rides.length,
                  itemBuilder: (context, index) {
                    final ride = rides[index];
                    final data = ride.data() as Map<String, dynamic>;
                    final requestedBy = List<String>.from(data['requestedBy'] ?? []);

                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 6),
                      elevation: 4,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      child: ExpansionTile(
                        title: Text("${data['from']} → ${data['to']}",
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16)),
                        subtitle: Text(
                            "Seats: ${data['seatsAvailable']}  |  Date: ${DateTime.fromMillisecondsSinceEpoch(data['dateTime'].millisecondsSinceEpoch)}"),
                        children: [
                          if (requestedBy.isEmpty)
                            const Padding(
                              padding: EdgeInsets.all(12.0),
                              child: Text("No requests yet"),
                            ),
                          for (var uid in requestedBy)
                            FutureBuilder<DocumentSnapshot>(
                              future: FirebaseFirestore.instance
                                  .collection('users')
                                  .doc(uid)
                                  .get(),
                              builder: (context, userSnapshot) {
                                if (!userSnapshot.hasData) {
                                  return const ListTile(
                                      title: Text("Loading user..."));
                                }
                                final userData = userSnapshot.data!.data()
                                as Map<String, dynamic>;
                                return ListTile(
                                  leading: const Icon(Icons.person),
                                  title: Text(userData['name'] ?? "Unknown User"),
                                  subtitle: Text(userData['email'] ?? ""),
                                  trailing: ElevatedButton(
                                    onPressed: () async {
                                      // Approve logic: reduce seat & remove user from requestedBy
                                      if (data['seatsAvailable'] > 0) {
                                        await FirebaseFirestore.instance
                                            .collection('rides')
                                            .doc(ride.id)
                                            .update({
                                          'seatsAvailable':
                                          data['seatsAvailable'] - 1,
                                          'requestedBy':
                                          FieldValue.arrayRemove([uid])
                                        });

                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(const SnackBar(
                                            content:
                                            Text("Request Approved!")));
                                      }
                                    },
                                    child: const Text("Approve"),
                                  ),
                                );
                              },
                            ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
