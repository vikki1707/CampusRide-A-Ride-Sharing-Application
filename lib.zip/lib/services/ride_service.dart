import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

Future<String> offerRide({
  required String origin,
  double? originLat,
  double? originLng,
  required String destination,
  double? destinationLat,
  double? destinationLng,
  required DateTime departureTime,
  required int availableSeats,
  int costPerSeat = 0,
  bool isEventRide = false,
  String? eventId,
  bool isAcceptingMidway = false,
}) async {
  final user = FirebaseAuth.instance.currentUser;
  if (user == null) throw Exception('Not logged in');

  final docRef = await FirebaseFirestore.instance.collection('rides').add({
    'driverId': user.uid,
    'driverName': user.displayName ?? user.email ?? 'Driver',
    'origin': origin,
    'originLat': originLat,
    'originLng': originLng,
    'destination': destination,
    'destinationLat': destinationLat,
    'destinationLng': destinationLng,
    'departureTime': Timestamp.fromDate(departureTime.toUtc()),
    'availableSeats': availableSeats,
    'costPerSeat': costPerSeat,
    'joinedUsers': <String>[],
    'isEventRide': isEventRide,
    'eventId': eventId,
    'status': 'scheduled',
    'isAcceptingMidway': isAcceptingMidway,
    'createdAt': FieldValue.serverTimestamp(),
  });

  return docRef.id;
}
